import os,cv2
import numpy as np
import matplotlib.pyplot as plt


from sklearn.utils import shuffle
from sklearn.cross_validation import train_test_split
from sklearn import preprocessing
	

from keras import backend as K
K.set_image_dim_ordering('tf')

from keras.utils import np_utils
from keras.models import Sequential
from keras.layers.core import Dense, Dropout, Activation, Flatten
from keras.layers.convolutional import Convolution2D, MaxPooling2D
from keras.optimizers import SGD,RMSprop,adam

img_rows=30
img_cols=30
num_channel=1
num_epoch=1500

data_path = '/home/ganesh/Downloads/basic-motion-detection/basic-motion-detection/dataset'
data_dir_list = sorted(os.listdir(data_path))

num_classes = 5

#def image_to_feature_vector(image, size=(128, 128)):
#		return cv2.resize(image, size).flatten()
	
img_data_list=[]
for dataset in data_dir_list:
        input_img=cv2.imread(data_path + '/'+ dataset )
        input_img=cv2.cvtColor(input_img, cv2.COLOR_BGR2GRAY)
        input_img_resize=cv2.resize(input_img,(40,40))
        img_data_list.append(input_img_resize)
img_data = np.array(img_data_list)
img_data = img_data.astype('float32')
img_data /= 255
print (img_data.shape)

img_data= np.expand_dims(img_data, axis=4) 
print (img_data.shape)

num_of_samples = img_data.shape[0]
labels = np.ones((num_of_samples,),dtype='int64')

labels[0:500]=0
labels[500:1000]=1
labels[1000:1500]=2
labels[1500:2000]=3
labels[2000:2500]=4
	  
names = ['boar','elephant','monkey','peacock','rats']
	  

Y = np_utils.to_categorical(labels, num_classes)

x,y = shuffle(img_data,Y, random_state=2)
X_train, X_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=2)


input_shape=img_data[0].shape
					
model = Sequential()
model.add(Convolution2D(32,3, 3,border_mode='same',input_shape=(40,40,1)))
model.add(Activation('relu'))
model.add(MaxPooling2D(pool_size=(2, 2)))
model.add(Dropout(0.5))

model.add(Convolution2D(64, 3, 3))
model.add(Activation('relu'))
model.add(MaxPooling2D(pool_size=(2, 2)))
model.add(Dropout(0.5))

model.add(Flatten())
model.add(Dense(64))
model.add(Activation('relu'))
model.add(Dropout(0.5))
model.add(Dense(num_classes))
model.add(Activation('softmax'))


model.summary()
model.get_config()
model.layers[0].get_config()
model.layers[2].input_shape			
model.layers[2].output_shape			
model.layers[0].get_weights()
np.shape(model.layers[0].get_weights()[0])
model.layers[0].trainable

model.compile(loss='categorical_crossentropy', optimizer='sgd',metrics=["accuracy"])

hist = model.fit(X_train, y_train, batch_size=20, nb_epoch=300, verbose=1, validation_data=(X_test, y_test))

score = model.evaluate(X_train, y_train, show_accuracy=True, verbose=0)
print('Train Loss:', score[0])
print('Train accuracy:', score[1])

score = model.evaluate(X_test, y_test, show_accuracy=True, verbose=0)
print('Test Loss:', score[0])
print('Test accuracy:', score[1])


test_image = X_test[0:1]
print (test_image.shape)

print(model.predict(test_image))
print(model.predict_classes(test_image))
print(y_test[0:1])

filename='/home/ganesh/Downloads/basic-motion-detection/basic-motion-detection/trained_model8.hdf5'
model.save_weights(filename,overwrite=True)

path='/home/ganesh/Downloads/basic-motion-detection/basic-motion-detection/test_images/11.jpg'
#test_image = cv2.imread(path)
image_paths=sorted([os.path.join(path, f) for f in os.listdir(path)])
for image_path in image_paths:
    test_image = cv2.imread(image_path)
    test_image=cv2.cvtColor(test_image, cv2.COLOR_BGR2GRAY)
    test_image=cv2.resize(test_image,(128,128))
    test_image = np.array(test_image)
    test_image = test_image.astype('float32')
    test_image /= 255
    #print (test_image.shape)
   
    test_image= np.expand_dims(test_image, axis=3) 
    test_image= np.expand_dims(test_image, axis=0)
    #print (test_image.shape)
    print(image_path)
    print((model.predict(test_image)))
    print(model.predict_classes(test_image))
    












