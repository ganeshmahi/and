import os,cv2
import numpy as np
import matplotlib.pyplot as plt
from collections import Counter
import sys
import shutil

from sklearn.utils import shuffle
from sklearn.cross_validation import train_test_split
from sklearn import preprocessing
	

from keras import backend as K
K.set_image_dim_ordering('tf')

from keras.utils import np_utils
from keras.models import Sequential
from keras.layers.core import Dense, Dropout, Activation, Flatten
from keras.layers.convolutional import Convolution2D, MaxPooling2D
from keras.optimizers import SGD,RMSprop,adam

from gpiozero import Buzzer
from time import sleep
from twilio.rest import Client


class_freq=[]
class_name=""
class_num=0
prob=[]
flag=0



#model = Sequential()
num_classes = 5
model = Sequential()
model.add(Convolution2D(32,3, 3,border_mode='same',input_shape=(40,40,1)))
model.add(Activation('relu'))
model.add(MaxPooling2D(pool_size=(2, 2)))
model.add(Dropout(0.5))

model.add(Convolution2D(64, 3, 3))
model.add(Activation('relu'))
model.add(MaxPooling2D(pool_size=(2, 2)))
model.add(Dropout(0.5))

model.add(Flatten())
model.add(Dense(64))
model.add(Activation('relu'))
model.add(Dropout(0.5))
model.add(Dense(num_classes))
model.add(Activation('softmax'))


model.summary()
#model.get_config()
#model.layers[0].get_config()
#model.layers[2].input_shape			
#model.layers[2].output_shape			
#model.layers[0].get_weights()
#np.shape(model.layers[0].get_weights()[0])
#model.layers[0].trainable


filename='/home/ganesh/Downloads/basic-motion-detection/basic-motion-detection/trained_model8.hdf5'
model.load_weights(filename)


path='/home/ganesh/Downloads/basic-motion-detection/basic-motion-detection/video_test'
#path='/home/ganesh/Downloads/basic-motion-detection/basic-motion-detection/video_test/90.jpg'
class_freq=[]
b_class=0
e_class=0
m_class=0
p_class=0
r_class=0

image_paths=sorted([os.path.join(path, f) for f in os.listdir(path)])
for image_path in image_paths:
    test_image = cv2.imread(image_path)
    test_image=cv2.cvtColor(test_image, cv2.COLOR_BGR2GRAY)
    test_image=cv2.resize(test_image,(40,40))
    test_image = np.array(test_image)
    test_image = test_image.astype('float32')
    test_image /= 255
    test_image= np.expand_dims(test_image, axis=3) 
    test_image= np.expand_dims(test_image, axis=0)
    #print(image_path)
    print((model.predict(test_image)))
    final_prob=0
    prob=model.predict(test_image)
    maxi_prob=(max(prob))
    final_prob=(max(maxi_prob))
    print(final_prob)    
    print(model.predict_classes(test_image))
    class_num=model.predict_classes(test_image)
    if final_prob<0.90:
        flag=-1
        class_num=-1
    if class_num==0:
        b_class=b_class+1
        
    if class_num==1:
        e_class=e_class+1
        
    if class_num==2:
        m_class=m_class+1
        
    if class_num==3:
        p_class=p_class+1
        
    if class_num==4:
        r_class=r_class+1
        
        
if b_class>max(e_class,m_class,p_class,r_class):
    flag=0
if e_class>max(b_class,m_class,p_class,r_class):
    flag=1
if m_class>max(e_class,b_class,p_class,r_class):
    flag=2
if p_class>max(e_class,m_class,b_class,r_class):
    flag=3
if r_class>max(e_class,m_class,p_class,b_class):
    flag=4
    

if flag==0:
    class_name="Boar"
if flag==1:
    class_name="Elephant"
if flag==2:
    class_name="Monkey"
if flag==3:
    class_name="Peacock"
if flag==4:
    class_name="Rat"
    
print("Boar : " +str(b_class))
print("Elephant : "+str(e_class))
print("Monkey : "+str(m_class))
print("Peacock : "+str(p_class))
print("Rat : "+str(r_class))
if (b_class>30) or (e_class>30) or (p_class>30) or (m_class>30) or (r_class>30):
    message = "There is "+class_name+" in the field"
    print("There is "+class_name+" in the field")
    
    
    client = Client("ACf466d06698b5591270b9502e746253ed", "13f7c94c316d4168a92e31baf5811c90")
    client.messages.create(to="+919677230785",
                       from_="+17542276857",
                       body=message)
    
    #buzzer = Buzzer(17)
    #while True:
     #   buzzer.on()
      #  sleep(1)
       # buzzer.off()
        #sleep(1)
        
shutil.rmtree('/home/ganesh/Downloads/basic-motion-detection/basic-motion-detection/video_test') 
os.mkdir('/home/ganesh/Downloads/basic-motion-detection/basic-motion-detection/video_test')
    
        





		
