import smtplib

try:  
    server = smtplib.SMTP('smtp.gmail.com', 25)
    server.ehlo()
except:  
    print 'Something went wrong...'

'''
content = 'This is a test message'

#mail = smtplib.SMTP(host='smtp.gmail.com',port='587')
mail = smtplib.SMTP('localhost')

mail.ehlo()

mail.starttls()

mail.login('wildlifedetection@gmail.com','finalyearproject')
mail.set_debuglevel(1)

mail.sendmail('wildlifedetection@gmail.com','ganeshmahi88@gmail.com',content)

mail.close()
'''
