import cv2
import os

data_path = '/home/ganesh/Downloads/basic-motion-detection/basic-motion-detection/wildlife'
data_dir_list = sorted(os.listdir(data_path))
samplenum=0

img_data_list=[]
for dataset in data_dir_list:
    img_list=os.listdir(data_path+'/'+ dataset)
    for img in img_list:
        input_img=cv2.imread(data_path + '/'+ dataset + '/'+ img )
        rimg=cv2.flip(input_img,1)
        samplenum = samplenum+1
        cv2.imwrite("/home/ganesh/Downloads/basic-motion-detection/basic-motion-detection/flip_results/"+ str(samplenum) + ".jpg",rimg)
